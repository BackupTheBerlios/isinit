/*
 * Groupe 2XMI
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */
package iepp.application;
import iepp.Application;
import java.io.File;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.SAXParseException;
import org.xml.sax.SAXException;
import javax.xml.parsers.SAXParserFactory;
import com.sun.msv.verifier.ValidityViolation;
import org.iso_relax.verifier.VerifierFactory;
import org.iso_relax.verifier.Verifier;
import org.iso_relax.verifier.VerifierFilter;

public class ValidationXMI {
  private String validationFile;
  private String XMLFile;

  public ValidationXMI(String _validationFile, String _XMLFile) {
    validationFile = _validationFile;
    XMLFile = _XMLFile;
  }

  public String LancerValidation(){
    // parser factory has to be configured to be namespace aware.
    SAXParserFactory pf = SAXParserFactory.newInstance();
    pf.setNamespaceAware(true);

    // create a VerifierFactory
    VerifierFactory factory = new com.sun.msv.verifier.jarv.TheFactoryImpl(pf);
    try {
      // load a RELAX schema (or whatever schema you like)
      Verifier verifier = factory.newVerifier(new File(validationFile));

      // obtain XMLFilter
      VerifierFilter filter = verifier.getVerifierFilter();

      // parse a document
      filter.setParent(pf.newSAXParser().getXMLReader());
      filter.setContentHandler(new MyDefaultHandler());

      filter.parse(XMLFile);
      // if the execution reaches here, the document was valid
    }
    catch (ValidityViolation vv) {
      // the document was not valid
      // ValidityViolation extends SAXException, so this catch clause
      // is not mandatory.
      return new String(Application.getApplication().getTraduction("XMINotValid")+"\n"+vv.getMessage());
    }
    catch (SAXException e) {
      // other generic exceptions
      // bad XML architecture
      return new String(Application.getApplication().getTraduction("architectureXMLNotValid")+"\n"+e.getMessage());
    }
    catch (Exception ex) {
      // other exception
      // the validation didn't start
      return new String(Application.getApplication().getTraduction("ValidationNotStart")+"\n"+ex.getMessage());
    }
    return null;
  }
}

class MyDefaultHandler
    extends DefaultHandler {

  //flag to check if the xml document was valid
  public boolean isValid = true;

  //Receive notification of a recoverable error.
  public void error(SAXParseException se) {
    setValidity(se);
  }

  //Receive notification of a non-recoverable error.
  public void fatalError(SAXParseException se) {
    setValidity(se);
  }

  //Receive notification of a warning.
  public void warning(SAXParseException se) {
    setValidity(se);
  }

  private void setValidity(SAXParseException se) {
    isValid = false;
    System.out.println(se.toString());
  }
}
